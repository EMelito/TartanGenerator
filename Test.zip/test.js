var firstName = prompt("What is your first name (letters only please)?");
var lastName = prompt("What is your last name (letters only please)?");
var fName = firstName.toUpperCase();
var lName = lastName.toUpperCase();

var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
var alpha = alphabet.split("");

var canvas=document.getElementById('myCanvas');
var ctx=canvas.getContext('2d');

//Divide screen
var widthSpace = fName.length;
var heightSpace = lName.length;

//Build pattern



var fNameArray = fName.split("");
var lNameArray = lName.split("");

//var fNameArrayAlpha = fNameArray.sort();
//var lNameArrayAlpha = lNameArray.sort();

var fHueArray = new Array();
var lHueArray = new Array();

//Select colours
for (var i=0;i<fNameArray.length;i++){
	for (var j=0;j<alpha.length;j++){
		if (fNameArray[i] === alpha[j]){
			var letterIndex = j;
			var colour = Math.floor(letterIndex*360/26);
			fHueArray[i] = colour;
		}
	}
	// ctx.fillStyle='hsl(fHueArray[i], 100%, 50%)';
	// ctx.fillRect(80*i,0,80*i,100);
}

for (var k=0;k<lNameArray;k++){
	for (var l=0;l<alpha.length;l++){
		if (fNameArray[k] === alpha[l]){
			var letterIndex = l;
			var colour = Math.floor(letterIndex*360/26);
			lHueArray[k] = colour;
		}
	}
}


ctx.fillStyle='hsl(220,100%,50%)';
ctx.fillRect(0,0,80,100);

ctx.fillStyle='hsl(fHueArray[1],100%,50%)';
ctx.fillRect(80,0,160,100);

alert(fHueArray);

